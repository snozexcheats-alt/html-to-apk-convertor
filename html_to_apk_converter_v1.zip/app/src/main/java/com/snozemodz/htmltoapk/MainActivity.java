package com.snozemodz.htmltoapk;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import android.view.View;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;

public class MainActivity extends Activity {
    private EditText urlInput, appNameInput, packageInput;
    private TextView selectedFile;
    private String selectedType = "";
    private Uri iconUri;
    private static final int PICK_HTML = 101;
    private static final int PICK_ZIP = 102;
    private static final int PICK_ICON = 103;
    private final String whatsapp = "https://whatsapp.com/channel/0029Vb7gPeh35fLz2gereI0S";

    int bg = Color.rgb(7, 12, 24), panel = Color.rgb(15, 24, 43),
        blue = Color.rgb(0, 116, 255), white = Color.WHITE, muted = Color.rgb(160, 179, 210);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUI();
    }

    GradientDrawable shape(int color, int strokeColor, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(android.view.Gravity.CENTER_VERTICAL); return l;
    }
    LinearLayout.LayoutParams lp(int w, int h, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(margin, margin, margin, margin); return p;
    }
    Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(white);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(shape(color, color, 24));
        return b;
    }
    EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setText(value);
        e.setHint(hint); e.setHintTextColor(muted); e.setTextColor(white); e.setTextSize(15);
        e.setPadding(16, 8, 16, 8); e.setBackground(shape(Color.rgb(24,35,57), Color.rgb(54,76,116), 18));
        return e;
    }
    LinearLayout card() {
        LinearLayout c = column(); c.setPadding(16, 14, 16, 14);
        c.setBackground(shape(panel, Color.rgb(39,59,94), 22)); return c;
    }
    void buildUI() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = column(); root.setPadding(18, 18, 18, 22); scroll.addView(root);
        LinearLayout top = row();
        TextView logo = text("⌘", 28, blue, true); logo.setPadding(12,5,12,5);
        logo.setBackground(shape(Color.rgb(18,39,79), blue, 18));
        LinearLayout titleBox = column();
        titleBox.addView(text("HTML TO APK", 21, white, true));
        titleBox.addView(text("CONVERTOR  •  SNOZE MODZ", 11, muted, true));
        top.addView(logo); top.addView(titleBox, lp(0,-2,10));
        root.addView(top, lp(-1,-2,4));
        TextView hero = text("Build your Android app", 25, white, true);
        root.addView(hero, lp(-1,-2,20));
        root.addView(text("Turn your website files or URL into an Android app project.", 14, muted, false), lp(-1,-2,2));

        LinearLayout files = card();
        files.addView(text("CHOOSE SOURCE", 12, blue, true));
        Button html = button("＋   Select HTML files", Color.rgb(22,52,94));
        Button zip = button("＋   Select ZIP project", Color.rgb(42,35,85));
        html.setOnClickListener(v -> pick(PICK_HTML, "text/html"));
        zip.setOnClickListener(v -> pick(PICK_ZIP, "application/zip"));
        files.addView(html, lp(-1,54,6)); files.addView(zip, lp(-1,54,6));
        selectedFile = text("No file selected", 13, muted, false);
        files.addView(selectedFile, lp(-1,-2,8));
        root.addView(files, lp(-1,-2,16));

        LinearLayout web = card();
        web.addView(text("WEBSITE URL", 12, blue, true));
        urlInput = field("https://example.com", "");
        urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        web.addView(urlInput, lp(-1,54,8));
        root.addView(web, lp(-1,-2,12));

        LinearLayout settings = card();
        settings.addView(text("APP SETTINGS", 12, blue, true));
        appNameInput = field("App name", "My Website");
        packageInput = field("Package name", "com.snozemodz.myapp");
        settings.addView(text("Application name", 13, muted, false), lp(-1,-2,8));
        settings.addView(appNameInput, lp(-1,54,4));
        settings.addView(text("Package name", 13, muted, false), lp(-1,-2,8));
        settings.addView(packageInput, lp(-1,54,4));
        Button icon = button("Choose app icon (optional)", Color.rgb(24,35,57));
        icon.setOnClickListener(v -> pick(PICK_ICON, "image/*"));
        settings.addView(icon, lp(-1,50,8));
        root.addView(settings, lp(-1,-2,12));

        Button build = button("⚡   BUILD APK", blue);
        build.setTextSize(18);
        build.setOnClickListener(v -> {
            String url = urlInput.getText().toString().trim();
            if (selectedType.isEmpty() && url.isEmpty()) {
                toast("Select HTML/ZIP files or enter a website URL first."); return;
            }
            toast("Backend not connected yet. This button will build the real APK after backend setup.");
        });
        root.addView(build, lp(-1,60,18));

        Button channel = button("WhatsApp Channel  •  Join Now", Color.rgb(13,130,75));
        channel.setOnClickListener(v -> open(whatsapp));
        root.addView(channel, lp(-1,52,12));
        TextView credit = text("Created by SNOZE MODZ", 14, muted, true);
        credit.setGravity(android.view.Gravity.CENTER);
        root.addView(credit, lp(-1,-2,18));
        TextView version = text("VERSION 1.0  •  ANDROID", 11, muted, false);
        version.setGravity(android.view.Gravity.CENTER);
        root.addView(version, lp(-1,-2,5));
        setContentView(scroll);
    }
    void pick(int request, String mime) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType(mime); i.addCategory(Intent.CATEGORY_OPENABLE);
        if (request == PICK_HTML) i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/html","text/*","application/octet-stream"});
        if (request == PICK_ZIP) i.setType("application/zip");
        startActivityForResult(i, request);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == PICK_ICON) { iconUri = uri; toast("Icon selected."); return; }
        selectedType = request == PICK_HTML ? "HTML" : "ZIP";
        selectedFile.setText(selectedType + " file selected: " + uri.getLastPathSegment());
        selectedFile.setTextColor(Color.rgb(90,220,160));
    }
    void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("Unable to open link."); }
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
