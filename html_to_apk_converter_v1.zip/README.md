# HTML TO APK CONVERTOR — Android App v1

A native Android starter app by SNOZE MODZ with a professional dark/neon-blue interface.

## Current features
- HTML file picker
- ZIP website project picker
- Website URL input
- App name and package name inputs
- Optional icon picker
- WhatsApp channel link
- Branding: Created by SNOZE MODZ

## Important
The Build APK button is not connected to the conversion backend yet. It intentionally displays a message instead of pretending to convert. Backend integration is the next phase.

## Build
Use Android Studio with Android SDK 35 and Gradle 8.9, or run the included GitHub Actions workflow to build the app APK.
